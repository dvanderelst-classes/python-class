# The Pandas For Everyone Teaching Slides

Thanks for considering to use the slide deck for Pandas for Everyone!

I've currently provided the working slides for Part 1 of the book. NOTE: The rest of the instructor materials will be posted later this spring. 

The updated README for the slides can be found on the main github repository URL: https://github.com/chendaniely/pandas_for_everyone#teaching-slides

There you will find the up-to-date setup and installation instructions and any other notes and comments related to the book and slide deck.
The issue tracker is one way to provide feedback,
and you can always send me an email at chendaniely@gmail.com, just be sure to add `[PFE]` in the subject line so I make sure it doesn't get overlooked.

If you have gone through the book, please let me know with an Amazon review!
I'm sure my mom would appreciate it :)

Below I've copy/pasted the current text in the github README for the teaching slides:

# Teaching Slides

For those instructors who are using the teaching slide deck version of the book.
Each chapter is split into it's own slide deck.
There are multiple versions for each chapter.

1. Jupyter notebook (ipynb)
2. PDF
3. HTML

The slides are created using
[Damian Avila's](http://www.damian.oquanta.info/)
[RISE](https://damianavila.github.io/RISE/index.html)
Jupyter/IPython Slideshow Extension.
Thus, you can choose to install the RISE extension and live render and display the Jupyter notebooks (ipynb).
Since each chapter is a Jupyter notebook at heart, the conversions to PDF and HTML are performed using

```bash
jupyter nbconvert --to slides your_talk.ipynb --post serve
```

More about useage ange converting to the PDF can be found on the RISE documentation page on
[useage](https://damianavila.github.io/RISE/usage.html).

## No Powerpoint (.ppt/.odp)

RISE's back end uses reveal.js.
Unfortunately there is [no way to go from a reveal.js presentation to powerpoint](https://github.com/hakimel/reveal.js/issues/1702)
Having said that,
if there's a way we can jerry-rig something together using the the given capabilties of RISE and reveal.js please let me know.