# Assign a radius
radius = 20 # radius is now 20

# Compute area
area = radius * radius * 3.14159

# Display results
print("The area for the circle of radius " + \
  str(radius) + " is " + str(area))