# Compute expression
print((10.5 + 2 * 3) / (45 � 3.5))
