class Displayable:
    def getX(self): # Get x-coordinate of the vertex
        return 0

    def getY(self): # Get y-coordinate of the vertex
        return 0

    def getName(self): # Get display name of the vertex
        return ""