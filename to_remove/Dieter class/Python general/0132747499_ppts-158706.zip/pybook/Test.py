print("Welcome to Python")
print("Python is fun")
print("Programming is fun")
