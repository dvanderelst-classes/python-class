from tkinter import * 
from CircleFromGeometricObject import Circle

s = {3, Circle(45)}
print(s)